(function (app) {
  'use strict';

  app.registerModule('purchases');
}(ApplicationConfiguration));
